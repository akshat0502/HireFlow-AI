import { useCallback, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";

import JobForm from "../../components/jobs/JobForm";

import {
    getJobById,
    updateJob
} from "../../services/jobService";

function EditJob() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [job, setJob] = useState(null);

    const [loading, setLoading] = useState(true);

    /**
     * Load Job
     */
    const loadJob = useCallback(async () => {

        setLoading(true);

        try {

            const response = await getJobById(id);

            setJob(response.data);

        }

        catch (error) {

            console.error(error);

            toast.error("Unable to load job.");

        }

        finally {

            setLoading(false);

        }

    }, [id]);

    /**
     * Fetch Job on page load
     */
    useEffect(() => {

        loadJob();

    }, [loadJob]);

    /**
     * Update Job
     */
    const submitJob = async (data) => {

        try {

            await updateJob(id, data);

            toast.success("Job updated successfully.");

            navigate("/jobs");

        }

        catch (error) {

            console.error(error);

            toast.error("Unable to update job.");

        }

    };

    if (loading) {

        return (

            <div className="flex justify-center items-center h-[70vh]">

                <h2 className="text-3xl font-bold">

                    Loading Job...

                </h2>

            </div>

        );

    }

    if (!job) {

        return (

            <div className="flex justify-center items-center h-[70vh]">

                <h2 className="text-3xl font-bold text-red-500">

                    Job Not Found

                </h2>

            </div>

        );

    }

    return (

        <div className="max-w-5xl mx-auto">

            <div className="mb-8">

                <h1 className="text-4xl font-bold">

                    Edit Job

                </h1>

                <p className="text-slate-500 mt-2">

                    Update the job details.

                </p>

            </div>

            <JobForm

                defaultValues={job}

                loading={loading}

                onSubmit={submitJob}

            />

        </div>

    );

}

export default EditJob;