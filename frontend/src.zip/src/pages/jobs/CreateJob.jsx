import { useState } from "react";

import { useNavigate } from "react-router-dom";

import toast from "react-hot-toast";

import JobForm from "../../components/jobs/JobForm";

import { createJob } from "../../services/jobService";

function CreateJob() {

    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);

    const submitJob = async (data) => {

        setLoading(true);

        try {

            await createJob(data);

            toast.success("Job Created Successfully");

            navigate("/jobs");

        }

        catch (error) {

            console.error(error);

            toast.error("Unable to create job");

        }

        finally {

            setLoading(false);

        }

    };

    return (

        <div className="max-w-5xl mx-auto">

            <h1 className="text-4xl font-bold mb-8">

                Create New Job

            </h1>

            <JobForm

                loading={loading}

                defaultValues={{

                    title: "",

                    company: "",

                    location: "",

                    salary: "",

                    description: "",

                    skills: "",

                    employmentType: "Full Time",

                    experience: 0

                }}

                onSubmit={submitJob}

            />

        </div>

    );

}

export default CreateJob;