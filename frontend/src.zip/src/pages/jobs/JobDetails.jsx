import { useCallback, useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Building2,
  MapPin,
  IndianRupee,
  Briefcase,
  ArrowLeft,
  Pencil,
} from "lucide-react";
import toast from "react-hot-toast";

import { getJobById } from "../../services/jobService";

function JobDetails() {
  const { id } = useParams();

  const [job, setJob] = useState(null);

  const [loading, setLoading] = useState(true);

  /**
   * Load Job Details
   */
  const loadJob = useCallback(async () => {
    setLoading(true);

    try {
      const response = await getJobById(id);

      setJob(response.data);
    } catch (error) {
      console.error(error);

      toast.error("Unable to load job.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  /**
   * Load Job
   */
  useEffect(() => {
    loadJob();
  }, [loadJob]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[70vh]">
        <h1 className="text-3xl font-bold">Loading Job...</h1>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="flex justify-center items-center h-[70vh]">
        <h1 className="text-3xl font-bold text-red-500">Job Not Found</h1>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}

      <div className="flex justify-between items-center mb-8">
        <Link
          to="/jobs"
          className="
                    flex
                    items-center
                    gap-2
                    text-blue-600
                    hover:text-blue-800"
        >
          <ArrowLeft size={20} />
          Back to Jobs
        </Link>

        <Link
          to={`/jobs/edit/${job.id}`}
          className="
                    bg-blue-600
                    hover:bg-blue-700
                    text-white
                    px-5
                    py-2
                    rounded-lg
                    flex
                    items-center
                    gap-2"
        >
          <Pencil size={18} />
          Edit Job
        </Link>
      </div>

      {/* Card */}

      <div
        className="bg-white rounded-3xl shadow-lg
hover:shadow-2xl
transition-all
duration-300-lg p-8"
      >
        <h1 className="text-4xl font-bold">{job.title}</h1>

        <p className="text-slate-500 mt-2 text-lg">{job.company}</p>

        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <div className="flex items-center gap-3">
            <Building2 className="text-blue-600" size={22} />

            <span>{job.company}</span>
          </div>

          <div className="flex items-center gap-3">
            <MapPin className="text-red-500" size={22} />

            <span>{job.location}</span>
          </div>

          <div className="flex items-center gap-3">
            <IndianRupee className="text-green-600" size={22} />

            <span>₹ {job.salary}</span>
          </div>

          <div className="flex items-center gap-3">
            <Briefcase className="text-purple-600" size={22} />

            <span>{job.experience} Year(s)</span>
          </div>
        </div>

        {/* Employment Type */}

        <div className="mt-8">
          <span
            className="
                        inline-block
                        bg-blue-100
                        text-blue-700
                        px-4
                        py-2
                        rounded-full"
          >
            {job.employmentType}
          </span>
        </div>

        {/* Description */}

        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-3">Job Description</h2>

          <p className="text-slate-700 leading-7">{job.description}</p>
        </div>

        {/* Skills */}

        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-3">Required Skills</h2>

          <div className="flex flex-wrap gap-3">
            {(job.skills ?? "").split(",").map((skill, index) => (
              <span
                key={index}
                className="
                                    bg-slate-200
                                    px-3
                                    py-2
                                    rounded-full"
              >
                {skill.trim()}
              </span>
            ))}
          </div>
        </div>

        {/* Recruiter */}

        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-3">Recruiter</h2>

          <p>{job.recruiterName}</p>
        </div>

        {/* Status */}

        <div className="mt-8">
          <span
            className="
                        bg-green-100
                        text-green-700
                        px-4
                        py-2
                        rounded-full"
          >
            {job.status}
          </span>
        </div>
      </div>
    </div>
  );
}

export default JobDetails;
